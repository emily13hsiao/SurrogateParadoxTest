if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("s", "x", "x1", "x2", "xlim", "y", "z", "z_bin"))
}

